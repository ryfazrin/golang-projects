package pustakasaya

// penulisan nama fungsi huruf kapital
func Penjumlahan(a int, b int) int {
	c := a + b
	return c
}

// penulisan nama funsi huruf kecil
func Perkalian(a int, b int) int {
	c := a * b
	return c
}



