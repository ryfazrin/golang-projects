package controller

// direktori tempat bekerja
var Dir_Name ="E:/PSMK/Project/Webserver2/"
var BaseURL ="http://localhost:8081/"
